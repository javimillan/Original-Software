# Angular 6

This is the source code of Angular 6 series streaming on [codedamn](https://www.youtube.com/watch?v=UoVytwPk3iA&list=PLYxzS__5yYQlqCmHqDyW3yo5V79C7eaTe)

## Getting the right files

This repo contains codes from all tutorials. Go to the commit history to find the appropirate commit from which you have to pull the repo. This repo is updated after **every** tutorial. Check commits [here](https://github.com/mehulmpt/angular6-youtube/commits/master)

## How to use this repo?

Clone this repo and run `npm install` to install the required packages.

## Still need support?

Feel free to file an issue [here](https://github.com/mehulmpt/angular6-youtube/issues) and mention the commit/tutorial number where you face problem.